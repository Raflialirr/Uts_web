<?php
// konfigurasi database
$host       =   "localhost";
$user       =   "root";
$password   =   "";
$database   =   "web_portal_berita";
// perintah php untuk akses ke database
$koneksi = mysqli_connect($host, $user, $password, $database);
?>